/* ═══════════════════════════════════════
   StudyFree — app.js
   All frontend logic
════════════════════════════════════════ */

// ── STATE ──
let currentMode = 'flashcards';
let currentSrc  = 'text';
let pdfExtracted = null;   // { text, pages, chars } | null
let imgData      = null;   // { base64, mime } | null
let cards        = [];
let cardIdx      = 0;
let seenCards    = new Set();
let qAnswered    = 0, qCorrect = 0, qTotal = 0, qAnsweredSet = new Set();

// ── SCREEN NAVIGATION ──
function showScreen(name) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById('screen-' + name).classList.add('active');
  window.scrollTo(0, 0);
}

function toggleMenu() {
  document.getElementById('mobile-menu').classList.toggle('open');
}

// ── OPEN MODE FROM HOME ──
function openMode(mode) {
  currentMode = mode;
  showScreen('input');
  setupInput();
  updateModeBtns();
}

// ── INPUT SCREEN SETUP ──
function setupInput() {
  const titles = {
    flashcards: 'Generate Flashcards',
    quiz:       'Generate a Quiz',
    notes:      'Generate Study Notes'
  };
  const subs = {
    flashcards: 'Add your study material below and get interactive flip cards',
    quiz:       'Add your study material below and get a scored multiple-choice quiz',
    notes:      'Add your study material below and get clean, organised study notes'
  };
  document.getElementById('panel-title').textContent = titles[currentMode];
  document.getElementById('panel-sub').textContent   = subs[currentMode];
  buildOptionsBar();
  updateGenButton();
}

function setMode(mode) {
  currentMode = mode;
  updateModeBtns();
  setupInput();
}

function updateModeBtns() {
  ['flashcards','quiz','notes'].forEach(m => {
    document.getElementById('mode-' + m)?.classList.toggle('active', m === currentMode);
  });
}

function setSrc(src) {
  currentSrc = src;
  // update sidebar buttons
  ['text','pdf','image','youtube'].forEach(s => {
    document.getElementById('src-' + s)?.classList.toggle('active', s === src);
  });
  // update panels
  document.querySelectorAll('.source-panel').forEach(p => p.classList.remove('active'));
  document.getElementById('panel-' + src)?.classList.add('active');
  // update tip
  updateTip();
}

function updateTip() {
  const tips = {
    text:    'Paste your notes or textbook content and click Generate.',
    pdf:     'Upload a PDF — text is extracted automatically. Works best on text-based PDFs (not scanned images).',
    image:   'Take a clear, well-lit photo of your handwritten notes. AI will read all the text.',
    youtube: 'Paste a YouTube link, then describe the video topic in detail below it.'
  };
  document.getElementById('sidebar-tip-text').textContent = tips[currentSrc] || '';
}

function buildOptionsBar() {
  const bar = document.getElementById('options-bar');
  if (currentMode === 'flashcards') {
    bar.innerHTML = `
      <div class="opt-group">
        <span class="opt-label">Number of cards</span>
        <select id="opt-count">
          <option value="6">6 cards</option>
          <option value="10" selected>10 cards</option>
          <option value="15">15 cards</option>
          <option value="20">20 cards</option>
        </select>
      </div>`;
  } else if (currentMode === 'quiz') {
    bar.innerHTML = `
      <div class="opt-group">
        <span class="opt-label">Number of questions</span>
        <select id="opt-count">
          <option value="5">5 questions</option>
          <option value="8" selected>8 questions</option>
          <option value="10">10 questions</option>
          <option value="15">15 questions</option>
        </select>
      </div>
      <div class="opt-group">
        <span class="opt-label">Question type</span>
        <select id="opt-type">
          <option value="mixed">Mixed types</option>
          <option value="mcq">Multiple choice</option>
          <option value="truefalse">True / False</option>
          <option value="short">Short answer</option>
        </select>
      </div>`;
  } else {
    bar.innerHTML = `
      <div class="opt-group">
        <span class="opt-label">Notes style</span>
        <select id="opt-style">
          <option value="structured">Structured summary</option>
          <option value="bullet">Bullet points</option>
          <option value="detailed">Detailed notes</option>
        </select>
      </div>`;
  }
}

function updateGenButton() {
  const labels = {
    flashcards: '✨ Generate Flashcards',
    quiz:       '🧠 Generate Quiz',
    notes:      '📝 Generate Notes'
  };
  document.getElementById('gen-label').textContent = labels[currentMode];
}

// character counter for textarea
document.getElementById('text-input')?.addEventListener('input', function() {
  document.getElementById('char-count').textContent = this.value.length.toLocaleString() + ' characters';
});

// ── PDF HANDLING ──
async function handlePDF(input) {
  const file = input.files[0];
  if (!file) return;

  pdfExtracted = null;
  showFileResult('pdf-result', 'loading', '📄', file.name, 'Extracting text…');

  const formData = new FormData();
  formData.append('pdf', file);

  try {
    const resp = await fetch('/api/extract-pdf', { method: 'POST', body: formData });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error || 'PDF extraction failed');
    pdfExtracted = data;
    showFileResult('pdf-result', 'success', '✅', file.name,
      `${data.chars.toLocaleString()} characters extracted from ${data.pages} page${data.pages > 1 ? 's' : ''} — Ready!`);
  } catch (err) {
    showFileResult('pdf-result', 'error', '⚠️', 'Error', err.message);
  }
}

function showFileResult(containerId, type, icon, name, detail) {
  const el = document.getElementById(containerId);
  if (!el) return;
  const nameClass = type === 'success' ? 'success-text' : type === 'error' ? 'error-text' : 'loading-text';
  el.innerHTML = `
    <div class="file-chip ${type}">
      <span class="fc-icon">${icon}</span>
      <div class="fc-info">
        <div class="fc-name ${nameClass}">${esc(name)}</div>
        <div class="fc-detail">${esc(detail)}</div>
      </div>
    </div>`;
}

// ── IMAGE HANDLING ──
function handleImage(input) {
  const file = input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    imgData = { base64: e.target.result.split(',')[1], mime: file.type };
    const prev = document.getElementById('img-preview');
    const wrap = document.getElementById('img-preview-wrap');
    prev.src = e.target.result;
    wrap.style.display = 'block';
    showFileResult('img-result', 'success', '🖼', file.name, 'Image loaded — AI will read all text from this photo');
  };
  reader.readAsDataURL(file);
}

// ── YOUTUBE HANDLING ──
function handleYT(url) {
  const match = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})/);
  const embedBox = document.getElementById('yt-embed-box');
  if (match) {
    document.getElementById('yt-frame').src = `https://www.youtube.com/embed/${match[1]}`;
    embedBox.style.display = 'block';
  } else {
    embedBox.style.display = 'none';
  }
}

// ── GET MATERIAL ──
async function getMaterial() {
  if (currentSrc === 'text') {
    const text = document.getElementById('text-input').value.trim();
    if (!text) { alert('Please paste your study material in the text box.'); return null; }
    if (text.length < 50) { alert('Please add more content — at least a few sentences.'); return null; }
    return { type: 'text', text };
  }

  if (currentSrc === 'pdf') {
    if (!pdfExtracted) { alert('Please upload a PDF and wait for it to finish processing (you\'ll see a green success message).'); return null; }
    if (pdfExtracted.chars < 50) { alert('The PDF did not contain readable text. Please try the "Photo of Notes" option and photograph the pages instead.'); return null; }
    const focus = document.getElementById('pdf-focus')?.value.trim();
    const text = pdfExtracted.text + (focus ? `\n\nFocus on: ${focus}` : '');
    return { type: 'text', text: text.substring(0, 8000) };
  }

  if (currentSrc === 'image') {
    if (!imgData) { alert('Please upload a photo of your notes first.'); return null; }
    return { type: 'image', base64: imgData.base64, mime: imgData.mime };
  }

  if (currentSrc === 'youtube') {
    const notes = document.getElementById('yt-notes').value.trim();
    if (!notes || notes.length < 30) { alert('Please describe the YouTube video topic in detail in the text box below the video.'); return null; }
    const url = document.getElementById('yt-url').value.trim();
    return { type: 'text', text: `YouTube video: ${url}\n\nDetailed topic description:\n${notes}` };
  }

  return null;
}

// ── BUILD API MESSAGES ──
function buildMessages(material, prompt) {
  if (material.type === 'image') {
    return [{
      role: 'user',
      content: [
        { type: 'image', source: { type: 'base64', media_type: material.mime, data: material.base64 } },
        { type: 'text', text: prompt }
      ]
    }];
  }
  return [{ role: 'user', content: `${prompt}\n\n===== STUDY MATERIAL =====\n${material.text}` }];
}

// ── CALL SERVER API ──
async function callAPI(messages, maxTokens = 3000) {
  const resp = await fetch('/api/generate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ messages, max_tokens: maxTokens })
  });

  const data = await resp.json();
  if (!resp.ok) throw new Error(data.error || `Server error ${resp.status}`);
  if (data.error) throw new Error(data.error.message || 'API error');

  const rawText = (data.content || []).map(b => b.text || '').join('');
  if (!rawText) throw new Error('Empty response from AI');

  return parseJSON(rawText);
}

// ── ROBUST JSON PARSER ──
function parseJSON(raw) {
  // Strip markdown code fences
  let text = raw.replace(/```json\s*/gi, '').replace(/```\s*/gi, '').trim();
  // Find outermost JSON structure
  const s1 = text.indexOf('['), s2 = text.indexOf('{');
  let start = (s1 === -1) ? s2 : (s2 === -1) ? s1 : Math.min(s1, s2);
  const e1 = text.lastIndexOf(']'), e2 = text.lastIndexOf('}');
  let end = Math.max(e1, e2);
  if (start === -1 || end === -1) throw new Error('AI returned unexpected format. Please try again.');
  const jsonStr = text.substring(start, end + 1);
  try {
    return JSON.parse(jsonStr);
  } catch (e) {
    throw new Error('Could not parse AI response. Please try regenerating.');
  }
}

// ── LOADING UI ──
function showLoading(title, sub) {
  const steps = [
    '📖 Reading your material…',
    '🧠 Understanding key concepts…',
    '✏️ Generating content…',
    '✅ Almost done…'
  ];
  document.getElementById('loading-title').textContent = title;
  document.getElementById('loading-sub').textContent   = sub;
  const stepsEl = document.getElementById('loading-steps');
  stepsEl.innerHTML = steps.map((s, i) => `<div class="loading-step" id="lstep-${i}">${s}</div>`).join('');
  document.getElementById('loading-overlay').classList.add('show');

  // Animate steps
  let i = 0;
  window._loadingInterval = setInterval(() => {
    if (i > 0) document.getElementById(`lstep-${i - 1}`)?.classList.replace('active', 'done');
    const stepEl = document.getElementById(`lstep-${i}`);
    if (stepEl) stepEl.classList.add('active');
    i++;
    if (i >= steps.length) clearInterval(window._loadingInterval);
  }, 4000);
}

function hideLoading() {
  clearInterval(window._loadingInterval);
  document.getElementById('loading-overlay').classList.remove('show');
}

// ── MAIN GENERATE ──
async function generate() {
  const material = await getMaterial();
  if (!material) return;

  const loadTitles = { flashcards: 'Creating your flashcards…', quiz: 'Building your quiz…', notes: 'Organising your notes…' };
  showLoading(loadTitles[currentMode], 'AI is reading your material — this takes 10–25 seconds');

  try {
    if (currentMode === 'flashcards') await doFlashcards(material);
    else if (currentMode === 'quiz')   await doQuiz(material);
    else                               await doNotes(material);
    showScreen('results');
  } catch (err) {
    hideLoading();
    showScreen('results');
    document.getElementById('results-topbar-title').textContent = 'Error';
    document.getElementById('results-body').innerHTML = `
      <div class="error-card">
        <h3>⚠️ Something went wrong</h3>
        <p>The AI couldn't generate content. Please go back, check your material, and try again. If your PDF didn't work, try copying the text and using the Paste Text option.</p>
        <code>${esc(err.message)}</code>
        <br><br>
        <button onclick="showScreen('input')" class="btn-secondary" style="margin:0 auto;display:block;">← Go Back</button>
      </div>`;
    return;
  }
  hideLoading();
}

// ════════════════════════════════
// FLASHCARDS
// ════════════════════════════════
async function doFlashcards(material) {
  const count = document.getElementById('opt-count')?.value || 10;
  const isImg = material.type === 'image';

  const prompt = `You are an expert university study assistant. Create exactly ${count} high-quality flashcards from the study material${isImg ? ' in this image (carefully read ALL visible text, diagrams and handwriting)' : ''}.

Each flashcard should have:
- "front": A clear, specific term, concept, question or key phrase (keep it concise)
- "back": A clear, complete definition, explanation or answer (informative but not too long)

Focus on the most important concepts. Make the backs easy to understand.

Return ONLY a valid JSON array with no other text, explanation or markdown:
[{"front":"...","back":"..."},{"front":"...","back":"..."}]`;

  const result = await callAPI(buildMessages(material, prompt), 3000);
  cards = Array.isArray(result) ? result : (result.flashcards || result.cards || []);
  if (!cards.length) throw new Error('No flashcards were returned. Please try again.');

  cardIdx   = 0;
  seenCards = new Set([0]);
  document.getElementById('results-topbar-title').textContent = `🃏 ${cards.length} Flashcards`;
  renderFlashcards();
}

function renderFlashcards() {
  const c = cards[cardIdx];
  const dots = cards.map((_, i) => {
    const cls = i === cardIdx ? 'current' : seenCards.has(i) ? 'seen' : '';
    return `<button class="fc-dot ${cls}" onclick="goCard(${i})" aria-label="Card ${i+1}"></button>`;
  }).join('');

  document.getElementById('results-body').innerHTML = `
    <div class="fc-progress-dots">${dots}</div>
    <div class="flashcard-scene" onclick="flipCard()" role="button" aria-label="Click to flip card">
      <div class="flashcard" id="fc-card">
        <div class="card-face card-front">
          <div class="card-label">Term / Concept</div>
          <div class="card-text">${esc(c.front)}</div>
          <div class="card-hint">👆 Click to reveal answer</div>
        </div>
        <div class="card-face card-back">
          <div class="card-label">Answer</div>
          <div class="card-text">${esc(c.back)}</div>
        </div>
      </div>
    </div>
    <div class="fc-nav">
      <button class="btn-nav" onclick="prevCard()" aria-label="Previous" ${cardIdx === 0 ? 'disabled' : ''}>←</button>
      <span class="fc-counter">${cardIdx + 1} / ${cards.length}</span>
      <button class="btn-nav" onclick="nextCard()" aria-label="Next" ${cardIdx === cards.length - 1 ? 'disabled' : ''}>→</button>
    </div>
    <div class="fc-actions">
      <button class="btn-secondary" onclick="shuffleCards()">🔀 Shuffle</button>
      <button class="btn-secondary" onclick="restartCards()">↺ Restart</button>
    </div>`;
}

function flipCard()    { document.getElementById('fc-card')?.classList.toggle('flipped'); }
function nextCard()    { if (cardIdx < cards.length - 1) { cardIdx++; seenCards.add(cardIdx); renderFlashcards(); } }
function prevCard()    { if (cardIdx > 0) { cardIdx--; renderFlashcards(); } }
function goCard(i)     { cardIdx = i; seenCards.add(i); renderFlashcards(); }
function shuffleCards(){ cards.sort(() => Math.random() - 0.5); cardIdx = 0; seenCards = new Set([0]); renderFlashcards(); }
function restartCards(){ cardIdx = 0; seenCards = new Set([0]); renderFlashcards(); }

// Keyboard navigation for flashcards
document.addEventListener('keydown', e => {
  if (document.getElementById('screen-results')?.classList.contains('active') && currentMode === 'flashcards') {
    if (e.key === 'ArrowRight') nextCard();
    if (e.key === 'ArrowLeft')  prevCard();
    if (e.key === ' ')          { e.preventDefault(); flipCard(); }
  }
});

// ════════════════════════════════
// QUIZ
// ════════════════════════════════
async function doQuiz(material) {
  const count = document.getElementById('opt-count')?.value || 8;
  const type  = document.getElementById('opt-type')?.value  || 'mixed';
  qAnswered = 0; qCorrect = 0; qAnsweredSet = new Set();

  const typeDesc = {
    mixed:     'a mix of multiple choice (with 4 lettered options A B C D), true/false, and short answer questions',
    mcq:       'multiple choice questions, each with 4 lettered answer options (A, B, C, D)',
    truefalse: 'true/false questions',
    short:     'short answer questions with clear, concise model answers'
  }[type];

  const isImg = material.type === 'image';
  const prompt = `You are an expert university study assistant. Generate exactly ${count} ${typeDesc} based on the study material${isImg ? ' in this image' : ''}.

Return ONLY a valid JSON array with no other text or markdown.

Format for multiple choice: {"type":"mcq","question":"Full question here?","options":["Option A text","Option B text","Option C text","Option D text"],"answer":1,"explanation":"Brief explanation of why this is correct"}
(answer = index 0-3 of the correct option. Options must NOT include the letter prefix — just the text.)

Format for true/false: {"type":"truefalse","question":"Statement here.","options":["True","False"],"answer":0,"explanation":"Brief explanation"}
(answer: 0=True is correct, 1=False is correct)

Format for short answer: {"type":"short","question":"Question here?","answer":"Clear, complete model answer"}

Make questions varied in difficulty. Cover the most important concepts from the material.`;

  const result = await callAPI(buildMessages(material, prompt), 4000);
  const questions = Array.isArray(result) ? result : (result.questions || []);
  if (!questions.length) throw new Error('No questions were returned. Please try again.');

  qTotal = questions.length;
  document.getElementById('results-topbar-title').textContent = `🧠 ${questions.length}-Question Quiz`;
  renderQuiz(questions);
}

function renderQuiz(questions) {
  let html = `
    <div class="score-card" id="score-card">
      <div class="score-pct" id="score-pct">—</div>
      <div class="score-info">
        <h3 id="score-label">Your Score</h3>
        <p id="score-detail">Answer the questions below to see your score</p>
      </div>
    </div>
    <div class="quiz-progress-bar">
      <div class="quiz-progress-fill" id="quiz-fill" style="width:0%"></div>
    </div>`;

  questions.forEach((q, i) => {
    const badgeClass = q.type === 'mcq' ? 'mcq' : q.type === 'truefalse' ? 'truefalse' : 'short';
    const badgeLabel = q.type === 'mcq' ? 'Multiple Choice' : q.type === 'truefalse' ? 'True / False' : 'Short Answer';
    const letters = ['A', 'B', 'C', 'D'];

    let body = '';
    if (q.type === 'mcq' || q.type === 'truefalse') {
      const gridClass = q.type === 'mcq' ? 'opts-grid' : '';
      body = `<div class="${gridClass}">` +
        (q.options || []).map((opt, j) => `
          <button class="opt-btn" id="qopt-${i}-${j}"
            onclick="checkOpt(${i}, ${j}, ${q.answer}, ${(q.options || []).length})">
            <span class="opt-letter">${q.type === 'mcq' ? letters[j] : (j === 0 ? 'T' : 'F')}</span>
            ${esc(opt)}
          </button>`).join('') +
        `</div>`;
      if (q.explanation) {
        body += `<div class="answer-box" id="qexp-${i}" style="display:none;">💡 <strong>Explanation:</strong> ${esc(q.explanation)}</div>`;
      }
    } else {
      body = `
        <button class="reveal-btn" onclick="revealShort(this, 'qans-${i}', ${i})">
          👁 Click to reveal model answer
        </button>
        <div class="answer-box" id="qans-${i}">
          <strong>Model Answer:</strong> ${esc(q.answer || '')}
        </div>`;
    }

    html += `
      <div class="q-card" style="animation-delay:${i * 0.04}s">
        <span class="q-badge ${badgeClass}">${badgeLabel}</span>
        <p class="q-text">Q${i + 1}. ${esc(q.question)}</p>
        ${body}
      </div>`;
  });

  document.getElementById('results-body').innerHTML = html;
}

function checkOpt(qi, chosen, correct, total) {
  if (qAnsweredSet.has(qi)) return;
  qAnsweredSet.add(qi);
  qAnswered++;

  // Disable all options for this question
  for (let j = 0; j < total; j++) {
    const btn = document.getElementById(`qopt-${qi}-${j}`);
    if (btn) btn.disabled = true;
  }

  const chosenBtn  = document.getElementById(`qopt-${qi}-${chosen}`);
  const correctBtn = document.getElementById(`qopt-${qi}-${correct}`);

  if (chosen === correct) {
    chosenBtn?.classList.add('correct');
    qCorrect++;
  } else {
    chosenBtn?.classList.add('wrong');
    correctBtn?.classList.add('correct');
  }

  // Show explanation if present
  const expEl = document.getElementById(`qexp-${qi}`);
  if (expEl) expEl.style.display = 'block';

  updateQuizScore();
}

function revealShort(btn, id, qi) {
  if (qAnsweredSet.has(qi)) return;
  qAnsweredSet.add(qi);
  qAnswered++;
  document.getElementById(id).style.display = 'block';
  btn.style.display = 'none';
  updateQuizScore();
}

function updateQuizScore() {
  const fill = document.getElementById('quiz-fill');
  if (fill) fill.style.width = (qAnswered / qTotal * 100) + '%';

  const mcqAndTF = [...qAnsweredSet].length;
  const pct = mcqAndTF > 0 && qCorrect >= 0 ? Math.round((qCorrect / Math.max(mcqAndTF, 1)) * 100) : 0;

  const pctEl   = document.getElementById('score-pct');
  const labelEl = document.getElementById('score-label');
  const detEl   = document.getElementById('score-detail');

  if (pctEl) {
    pctEl.textContent = pct + '%';
    pctEl.className   = 'score-pct ' + (pct >= 70 ? 'great' : pct >= 50 ? 'ok' : 'poor');
  }
  if (labelEl) labelEl.textContent = pct >= 70 ? '🎉 Great work!' : pct >= 50 ? '📚 Keep going!' : '💪 Keep studying!';
  if (detEl)   detEl.innerHTML = `<strong>${qCorrect}</strong> correct · <strong>${qAnswered}</strong> of ${qTotal} answered`;
}

// ════════════════════════════════
// NOTES
// ════════════════════════════════
async function doNotes(material) {
  const style  = document.getElementById('opt-style')?.value || 'structured';
  const isImg  = material.type === 'image';

  const styleGuide = {
    structured: 'Create a structured summary. Use <h3> for clear section headings and <p> for concise paragraphs. Cover all key topics.',
    bullet:     'Use <h3> for section headings and <ul><li> bullet points for all content. Make it extremely scannable and easy to review.',
    detailed:   'Be thorough and comprehensive. Use <h3> headings, <p> paragraphs, and <ul><li> lists with detailed explanations and examples.'
  }[style];

  const prompt = `You are an expert university study assistant. Create well-organised, comprehensive study notes from the material${isImg ? ' in this image (carefully read ALL visible text, diagrams and handwriting)' : ''}.

${styleGuide}

Important formatting rules:
- Wrap ALL key terms, important names, dates, and concepts in <strong> tags
- Organise content logically by topic
- Be accurate and use the exact content from the material
- Write in clear, student-friendly language

Return ONLY a JSON object with no other text or markdown:
{"notes":"<h3>Section Title</h3><p>Content with <strong>key terms</strong> highlighted.</p><ul><li>Bullet point</li></ul>"}`;

  const result  = await callAPI(buildMessages(material, prompt), 4000);
  const html    = typeof result === 'string' ? result : (result.notes || result.html || '');
  if (!html || html.length < 30) throw new Error('No notes content was returned. Please try again.');

  document.getElementById('results-topbar-title').textContent = '📝 Study Notes';
  document.getElementById('results-body').innerHTML = `
    <div class="notes-toolbar">
      <button class="btn-secondary" onclick="copyNotes()">📋 Copy Text</button>
      <button class="btn-secondary" onclick="printNotes()">🖨 Print Notes</button>
    </div>
    <div class="notes-output" id="notes-html">${html}</div>`;
}

function copyNotes() {
  const el = document.getElementById('notes-html');
  if (!el) return;
  navigator.clipboard.writeText(el.innerText)
    .then(() => showToast('✅ Notes copied to clipboard!'))
    .catch(() => showToast('❌ Copy failed — please select the text manually (Ctrl+A, Ctrl+C)'));
}

function printNotes() {
  const el = document.getElementById('notes-html');
  if (!el) return;
  const win = window.open('', '_blank');
  win.document.write(`<!DOCTYPE html><html><head>
    <title>Study Notes — StudyFree</title>
    <style>
      body{font-family:Georgia,serif;max-width:750px;margin:48px auto;color:#111;line-height:1.9;padding:0 24px;}
      h1{font-size:1.4rem;margin-bottom:8px;}
      h3{font-size:1rem;color:#1E3A8A;border-bottom:2px solid #DBEAFE;padding-bottom:7px;margin:24px 0 10px;}
      p{font-size:0.95rem;margin-bottom:12px;}
      strong{background:#FEF3C7;padding:0 3px;border-radius:2px;}
      ul{list-style:none;margin:8px 0 16px;}
      li{padding:5px 0 5px 18px;position:relative;font-size:0.92rem;}
      li::before{content:"▸ ";position:absolute;left:0;color:#2563EB;}
      @media print{body{margin:24px;}}
    </style>
  </head><body>
    <h1>📚 Study Notes — StudyFree</h1>
    <p style="color:#6B7280;font-size:0.8rem;margin-bottom:32px;">Generated on ${new Date().toLocaleDateString()}</p>
    ${el.innerHTML}
  </body></html>`);
  win.document.close();
  win.focus();
  win.print();
}

// ── TOAST ──
function showToast(msg) {
  const existing = document.getElementById('sf-toast');
  if (existing) existing.remove();
  const toast = document.createElement('div');
  toast.id = 'sf-toast';
  toast.style.cssText = `
    position:fixed;bottom:24px;left:50%;transform:translateX(-50%);
    background:#1F2937;color:#fff;padding:12px 24px;border-radius:8px;
    font-size:0.85rem;font-weight:600;z-index:9999;
    box-shadow:0 8px 24px rgba(0,0,0,0.2);
    animation:fadeSlide 0.3s ease;
  `;
  toast.textContent = msg;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 3000);
}

// ── DRAG OVER EFFECTS ──
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.drop-zone').forEach(zone => {
    zone.addEventListener('dragover',  e => { e.preventDefault(); zone.classList.add('drag-over'); });
    zone.addEventListener('dragleave', ()  => zone.classList.remove('drag-over'));
    zone.addEventListener('drop',      ()  => zone.classList.remove('drag-over'));
  });

  // Init
  setupInput();
  updateTip();
});

// ── HELPER ──
function esc(s) {
  if (!s) return '';
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
